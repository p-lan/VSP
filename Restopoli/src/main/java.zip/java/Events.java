import java.util.ArrayList;
import java.util.List;

public class Events {

    private List<Event> events = new ArrayList();


    public void addEvent(Event event){
        events.add(event);
    }

    public void delEvent(String game, String type, String name, String reason, String resource, String player){
        for(Event e : events){
            if(e.getGame().matches("https://141\\.22\\.34\\.15/cnt/\\d+\\.\\d+\\.\\d+\\.\\d+/\\d\\d\\d\\d(/\\w)+")
                    || e.getType().matches("[a-zA-Z]+") || e.getName().matches("[a-zA-Z_0-9]+") || e.getReason().matches("[a-zA-Z _0-9]+")
                    || e.getResource().matches("https://141\\.22\\.34\\.15/cnt/\\d+\\.\\d+\\.\\d+\\.\\d+/\\d\\d\\d\\d(/\\w)+")
                    || e.getPlayer().matches("https://141\\.22\\.34\\.15/cnt/\\d+\\.\\d+\\.\\d+\\.\\d+/\\d\\d\\d\\d(/\\w)+")){
                events.remove(e);
            }
        }
    }

    public Event getEvent(String id){
        for(Event e : events){
            if(e.getId().equals(id)){
                return e;
            }
        }
        return null;
    }

    public List<Event> getEvents(String game, String type, String name, String reason, String resource, String player){
        List<Event> temp = new ArrayList();

        for(Event e : events){
            if(e.getGame().matches("https://141\\.22\\.34\\.15/cnt/\\d+\\.\\d+\\.\\d+\\.\\d+/\\d\\d\\d\\d(/\\w)+")
                    || e.getType().matches("[a-zA-Z]+") || e.getName().matches("[a-zA-Z_0-9]+") || e.getReason().matches("[a-zA-Z _0-9]+")
                    || e.getResource().matches("https://141\\.22\\.34\\.15/cnt/\\d+\\.\\d+\\.\\d+\\.\\d+/\\d\\d\\d\\d(/\\w)+")
                    || e.getPlayer().matches("https://141\\.22\\.34\\.15/cnt/\\d+\\.\\d+\\.\\d+\\.\\d+/\\d\\d\\d\\d(/\\w)+")){
                temp.add(e);
            }
        }
        return temp;
    }
}